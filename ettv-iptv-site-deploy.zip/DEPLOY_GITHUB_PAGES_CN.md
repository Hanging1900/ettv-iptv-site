# GitHub Pages 网页部署步骤

因为当前电脑环境没有 `git` 和 `gh` 命令，最稳的方式是在你已经登录 GitHub 的 Chrome 里用网页上传。

## 1. 创建仓库

1. 打开 <https://github.com/new>
2. Repository name 填：`ettv-iptv-site`
3. 选择 `Public`
4. 不要勾选 `Add a README file`
5. 点击 `Create repository`

## 2. 上传文件

1. 在新仓库页面点击 `uploading an existing file`
2. 打开本机目录：

```text
C:\Users\18482\Documents\Codex\2026-06-16\iptv\outputs\ettv-iptv-site
```

3. 把目录里的所有文件和文件夹拖到 GitHub 上传区，包括：

```text
.github
data
scripts
.gitignore
.nojekyll
config.example.json
DEPLOY_GITHUB_PAGES_CN.md
index.html
README.md
site.js
styles.css
```

4. Commit message 可以写：`Initial IPTV site`
5. 点击 `Commit changes`

## 3. 配置授权 IPTV 源

1. 进入仓库 `Settings`
2. 左侧打开 `Secrets and variables` -> `Actions`
3. 点击 `New repository secret`
4. Name 填：

```text
IPTV_SOURCE_URLS
```

5. Secret 填你有授权使用的 M3U 播放列表地址；多个地址用换行分隔。
6. 点击 `Add secret`

## 4. 启用 GitHub Pages

1. 进入仓库 `Settings`
2. 左侧打开 `Pages`
3. Source 选择 `GitHub Actions`
4. 保存

## 5. 手动运行第一次部署

1. 进入仓库 `Actions`
2. 打开 `Update IPTV data and deploy`
3. 点击 `Run workflow`
4. 等它变成绿色成功状态

完成后 Pages 地址通常是：

```text
https://你的GitHub用户名.github.io/ettv-iptv-site/
```

频道 M3U 地址通常是：

```text
https://你的GitHub用户名.github.io/ettv-iptv-site/data/ettv-variety.m3u
```

后续会在北京时间每天 `02:00 / 10:00 / 18:00` 自动更新三次。
