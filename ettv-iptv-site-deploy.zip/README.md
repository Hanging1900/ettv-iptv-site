# ETTV Variety IPTV updater

This is a static website plus a scheduled updater for extracting the ETTV Variety / 东森综合台 entry from authorized IPTV playlists.

It does not scrape or bypass paid TV services. Add only playlist URLs that you are authorized to use.

## Local setup

1. Copy `config.example.json` to `config.json`.
2. Replace the example URL with your authorized M3U playlist URL.
3. Run:

```bash
node scripts/update.js
```

4. Start a static file server and open the local URL:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## GitHub Pages deployment

1. Create a new GitHub repository and upload these files.
2. In repository settings, enable GitHub Pages with `GitHub Actions` as the source.
3. Add a repository secret named `IPTV_SOURCE_URLS`.
4. Put one or more authorized M3U URLs in that secret. Separate multiple URLs with new lines. English commas also work for ordinary URLs, but new lines are safer.
5. Run the `Update IPTV data and deploy` workflow once manually.

The workflow updates three times per day at 02:00, 10:00, and 18:00 Asia/Shanghai time.

## Published files

- `data/ettv-variety.json`: machine-readable channel status and matched streams.
- `data/ettv-variety.m3u`: a generated M3U playlist containing matched authorized streams.
